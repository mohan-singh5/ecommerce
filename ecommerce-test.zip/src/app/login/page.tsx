import React from 'react'
import LoginRoot from './LoginRoot'

export default function page() {
    return (
        <LoginRoot />
    )
}
